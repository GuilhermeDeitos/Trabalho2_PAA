#include <iostream>
#include <vector>
#include <limits>

using namespace std;

void jhonson(int numVertices, int numArestas) {
    cout << "Executando o algoritmo de Johnson com " << numVertices << " vértices e " << numArestas << " arestas." << endl;
}

